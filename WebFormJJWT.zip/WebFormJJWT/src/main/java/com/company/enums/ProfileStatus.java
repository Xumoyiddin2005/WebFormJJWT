package com.company.enums;

public enum ProfileStatus {
    ACTIVE, BLOCK
}
